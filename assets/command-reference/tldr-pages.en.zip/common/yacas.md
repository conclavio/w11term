# yacas

> Yet Another Computer Algebra System.
> More information: <https://www.yacas.org/>.

- Start an interactive `yacas` session:

`yacas`

- [Interactive] While in a `yacas` session, execute a statement:

`{{Integrate(x)Cos(x)}};`

- [Interactive] While in a `yacas` session, display an example:

`Example();`

- [Interactive] Quit from a `yacas` session:

`quit`

- Execute one or more `yacas` scripts (without terminal or prompts), then exit:

`yacas -p -c {{path/to/script1 path/to/script2 ...}}`

- Execute and print the result of one statement, then exit:

`echo "{{Echo( Deriv(x)Cos(1/x) );}}" | yacas -p -c /dev/stdin`
